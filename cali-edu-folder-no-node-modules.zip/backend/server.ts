import express from 'express';
import cors from 'cors';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import path from 'path';

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Database connection
let db: any;

async function initDB() {
  db = await open({
    filename: path.join(__dirname, '../caliedu.db'),
    driver: sqlite3.Database
  });
}

// Authentication routes
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  
  try {
    const user = await db.get(
      'SELECT * FROM Users WHERE Username = ?',
      [username]
    );
    
    if (user && user.PasswordHash === password) { // Add proper password hashing
      res.json({
        success: true,
        user: {
          id: user.UserID,
          username: user.Username,
          email: user.Email,
          roleId: user.RoleID
        }
      });
    } else {
      res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Eligibility routes
app.get('/api/eligibility', async (req, res) => {
  try {
    const records = await db.all(`
      SELECT e.*, h.HouseholdName, h.Address 
      FROM EligibilityRecords e
      LEFT JOIN Households h ON e.HouseholdID = h.HouseholdID
    `);
    res.json(records);
  } catch (error) {
    console.error('Error fetching eligibility records:', error);
    res.status(500).json({ error: 'Failed to fetch eligibility records' });
  }
});

app.post('/api/eligibility', async (req, res) => {
  const { participantId, issuanceType, issuanceAmount, issuanceDate, householdId } = req.body;
  
  try {
    const result = await db.run(`
      INSERT INTO EligibilityRecords 
      (ParticipantID, IssuanceType, IssuanceAmount, IssuanceDate, ApprovalStatus, HouseholdID)
      VALUES (?, ?, ?, ?, 'Pending', ?)
    `, [participantId, issuanceType, issuanceAmount, issuanceDate, householdId]);
    
    res.status(201).json({ success: true, id: result.lastID });
  } catch (error) {
    console.error('Error creating eligibility record:', error);
    res.status(500).json({ error: 'Failed to create eligibility record' });
  }
});

// Start server
initDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
});
