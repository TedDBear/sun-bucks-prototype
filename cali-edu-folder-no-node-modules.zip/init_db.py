import sqlite3

conn = sqlite3.connect("caliedu.db")
c = conn.cursor()

c.execute("""
CREATE TABLE IF NOT EXISTS Roles (
    RoleID INT PRIMARY KEY,
    RoleName NVARCHAR(50),
    Description NVARCHAR(255)
);
""")

c.execute('''
    CREATE TABLE IF NOT EXISTS Users (
    UserID INT PRIMARY KEY,
    Username NVARCHAR(50) UNIQUE NOT NULL,
    PasswordHash NVARCHAR(255) NOT NULL,
    Email NVARCHAR(100),
    RoleID INT,
    MFAEnabled BIT DEFAULT 1,
    LastLogin DATETIME,
    FOREIGN KEY (RoleID) REFERENCES Roles(RoleID)
);
''')

# Create the admin_users table
c.execute('''
CREATE TABLE IF NOT EXISTS admin_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL
);
''')

c.execute(''' CREATE TABLE IF NOT EXISTS Households (
    HouseholdID INT PRIMARY KEY,
    HouseholdName NVARCHAR(100),
    Address NVARCHAR(255)
);
''')

c.execute('''CREATE TABLE IF NOT EXISTS EligibilityRecords (
    EligibilityID INT PRIMARY KEY,
    ParticipantID INT,
    IssuanceType NVARCHAR(50),
    IssuanceAmount DECIMAL(10,2),
    IssuanceDate DATE,
    ApprovalStatus NVARCHAR(50),
    HouseholdID INT,
    FOREIGN KEY (HouseholdID) REFERENCES Households(HouseholdID)
);
''')

c.execute('''CREATE TABLE IF NOT EXISTS SystemConfigs (
    ConfigKey NVARCHAR(100) PRIMARY KEY,
    ConfigValue NVARCHAR(255)
);
''')


c.execute("""CREATE TABLE IF NOT EXISTS AuditLogs (
    LogID INT PRIMARY KEY,
    UserID INT,
    Action NVARCHAR(255),
    TableAffected NVARCHAR(100),
    RecordID INT,
    OldValue NVARCHAR(1000),
    NewValue NVARCHAR(1000),
    ActionDate DATETIME,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);
""")

c.execute("""CREATE TABLE IF NOT EXISTS EBTAccounts (
    EBTAccountID INT PRIMARY KEY,
    EligibilityID INT,
    AccountNumber NVARCHAR(50),
    Status NVARCHAR(50),
    BenefitBalance DECIMAL(10,2),
    ExpungementDate DATE,
    FOREIGN KEY (EligibilityID) REFERENCES EligibilityRecords(EligibilityID)
);
""")

c.execute("""CREATE TABLE IF NOT EXISTS BenefitIssuances (
    IssuanceID INT PRIMARY KEY,
    EligibilityID INT,
    IssuanceDate DATE,
    IssuanceAmount DECIMAL(10,2),
    IssuanceType NVARCHAR(50),
    IsReplacement BIT DEFAULT 0,
    Approved BIT DEFAULT 0,
    FOREIGN KEY (EligibilityID) REFERENCES EligibilityRecords(EligibilityID)
);
""")

c.execute("""CREATE TABLE IF NOT EXISTS Documents (
    DocumentID INT PRIMARY KEY,
    EligibilityID INT,
    FileName NVARCHAR(255),
    FileType NVARCHAR(50),
    UploadedBy INT,
    UploadDate DATETIME,
    FOREIGN KEY (EligibilityID) REFERENCES EligibilityRecords(EligibilityID),
    FOREIGN KEY (UploadedBy) REFERENCES Users(UserID)
);""")

c.execute("""CREATE TABLE IF NOT EXISTS Comments (
    CommentID INT PRIMARY KEY,
    EligibilityID INT,
    UserID INT,
    CommentText NVARCHAR(1000),
    CreatedAt DATETIME,
    FOREIGN KEY (EligibilityID) REFERENCES EligibilityRecords(EligibilityID),
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);""")

c.execute("""CREATE TABLE IF NOT EXISTS Tasks (
    TaskID INT PRIMARY KEY,
    AssignedTo INT,
    CreatedBy INT,
    TaskType NVARCHAR(50),
    RelatedRecordID INT,
    DueDate DATE,
    Status NVARCHAR(50),
    CreatedAt DATETIME,
    FOREIGN KEY (AssignedTo) REFERENCES Users(UserID),
    FOREIGN KEY (CreatedBy) REFERENCES Users(UserID)
);""")

c.execute("""
    CREATE TABLE IF NOT EXISTS RolePermissions (
    RolePermissionID INT PRIMARY KEY,
    RoleID INT,
    PermissionName NVARCHAR(100),
    IsAllowed BIT,
    FOREIGN KEY (RoleID) REFERENCES Roles(RoleID)
);""")


c.execute("""
          CREATE TABLE IF NOT EXISTS RawCALPADS (
    CALPADS_ID INT PRIMARY KEY,
    SSID NVARCHAR(20),
    FirstName NVARCHAR(100),
    LastName NVARCHAR(100),
    DOB DATE,
    Address NVARCHAR(255),
    SchoolName NVARCHAR(100),
    ImportTimestamp DATETIME
);""")
c.execute("""
          CREATE TABLE IF NOT EXISTS RawCalSAWS (
    CalSAWS_ID INT PRIMARY KEY,
    CaseNumber NVARCHAR(50),
    FirstName NVARCHAR(100),
    LastName NVARCHAR(100),
    DOB DATE,
    Address NVARCHAR(255),
    ProgramType NVARCHAR(50),
    ImportTimestamp DATETIME
);""")
c.execute("""
    CREATE TABLE IF NOT EXISTS DeduplicationErrors (
    ErrorID INT PRIMARY KEY,
    Source NVARCHAR(20), -- 'CALPADS' or 'CalSAWS'
    RecordID INT,
    ErrorMessage NVARCHAR(255),
    Reviewed BIT DEFAULT 0,
    LoggedAt DATETIME
);""")
c.execute("""
          CREATE TABLE IF NOT EXISTS Communications (
    CommunicationID INT PRIMARY KEY,
    EligibilityID INT,
    CommunicationType NVARCHAR(20), -- 'Mail', 'Email', 'SMS'
    Content NVARCHAR(1000),
    SentDate DATETIME,
    SentBy INT,
    FOREIGN KEY (EligibilityID) REFERENCES EligibilityRecords(EligibilityID),
    FOREIGN KEY (SentBy) REFERENCES Users(UserID)
);
          """)

c.execute("""
          CREATE TABLE IF NOT EXISTS CommunicationTemplates (
    TemplateID INT PRIMARY KEY,
    TemplateName NVARCHAR(100),
    TemplateType NVARCHAR(20), -- 'Approval Notice', 'Reminder', etc.
    BodyText NVARCHAR(1000),
    CreatedBy INT,
    CreatedAt DATETIME,
    FOREIGN KEY (CreatedBy) REFERENCES Users(UserID)
);""")

c.execute("""
    CREATE TABLE IF NOT EXISTS AuditLogsEnhanced (
    LogID INT PRIMARY KEY,
    UserID INT,
    ActionType NVARCHAR(100), -- e.g., 'INSERT', 'UPDATE', 'DELETE'
    TableName NVARCHAR(100),
    RecordID INT,
    FieldName NVARCHAR(100),
    OldValue NVARCHAR(1000),
    NewValue NVARCHAR(1000),
    ActionDate DATETIME,
    FOREIGN KEY (UserID) REFERENCES Users(UserID)
);""")



conn.commit()
conn.close()

print("Database initialized with 'school' table.")
