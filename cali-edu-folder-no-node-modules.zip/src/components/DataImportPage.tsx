import React, { useState, useCallback } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Alert } from './ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Upload, 
  FileText, 
  AlertCircle, 
  CheckCircle, 
  Clock, 
  Download,
  Eye,
  RefreshCw,
  Database,
  FileX,
  Play,
  Pause,
  Settings,
  BarChart3
} from 'lucide-react';

interface ImportJob {
  id: string;
  fileName: string;
  source: 'CALPADS' | 'CalSAWS' | 'EDCS';
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'paused';
  progress: number;
  totalRecords: number;
  processedRecords: number;
  validRecords: number;
  errorRecords: number;
  duplicateRecords: number;
  startTime: string;
  endTime?: string;
  fileSize: string;
}

export function DataImportPage() {
  const [dragActive, setDragActive] = useState(false);
  const [selectedSource, setSelectedSource] = useState<'CALPADS' | 'CalSAWS' | 'EDCS'>('CALPADS');
  const [selectedJob, setSelectedJob] = useState<string | null>(null);

  const importJobs: ImportJob[] = [
    {
      id: 'IMP-2024-001',
      fileName: 'calpads_enrollment_jan2024.csv',
      source: 'CALPADS',
      status: 'completed',
      progress: 100,
      totalRecords: 15420,
      processedRecords: 15420,
      validRecords: 14890,
      errorRecords: 125,
      duplicateRecords: 405,
      startTime: '2024-01-15 09:30:00',
      endTime: '2024-01-15 10:15:00',
      fileSize: '2.4 MB'
    },
    {
      id: 'IMP-2024-002',
      fileName: 'calsaws_benefits_jan2024.xml',
      source: 'CalSAWS',
      status: 'processing',
      progress: 65,
      totalRecords: 8500,
      processedRecords: 5525,
      validRecords: 5234,
      errorRecords: 45,
      duplicateRecords: 246,
      startTime: '2024-01-15 14:20:00',
      fileSize: '1.8 MB'
    },
    {
      id: 'IMP-2024-003',
      fileName: 'edcs_meals_data_jan2024.csv',
      source: 'EDCS',
      status: 'failed',
      progress: 23,
      totalRecords: 12000,
      processedRecords: 2760,
      validRecords: 2456,
      errorRecords: 304,
      duplicateRecords: 0,
      startTime: '2024-01-15 11:45:00',
      endTime: '2024-01-15 12:12:00',
      fileSize: '3.1 MB'
    }
  ];

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileUpload(e.dataTransfer.files[0]);
    }
  }, []);

  const handleFileUpload = (file: File) => {
    console.log('Uploading file:', file.name);
    // Handle file upload logic here
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline', icon: React.ReactNode }> = {
      pending: { variant: 'secondary', icon: <Clock className="w-3 h-3" /> },
      processing: { variant: 'outline', icon: <RefreshCw className="w-3 h-3 animate-spin" /> },
      completed: { variant: 'default', icon: <CheckCircle className="w-3 h-3" /> },
      failed: { variant: 'destructive', icon: <AlertCircle className="w-3 h-3" /> },
      paused: { variant: 'secondary', icon: <Pause className="w-3 h-3" /> }
    };
    
    const config = variants[status];
    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        {config.icon}
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const getSourceBadge = (source: string) => {
    const colors: Record<string, string> = {
      CALPADS: 'bg-blue-100 text-blue-800',
      CalSAWS: 'bg-green-100 text-green-800',
      EDCS: 'bg-purple-100 text-purple-800'
    };
    
    return (
      <Badge variant="outline" className={colors[source]}>
        {source}
      </Badge>
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Data Import</h1>
          <p className="text-muted-foreground">Upload and process data from external systems</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Settings className="w-4 h-4 mr-2" />
            Configure Sources
          </Button>
          <Button variant="outline">
            <BarChart3 className="w-4 h-4 mr-2" />
            Import Reports
          </Button>
        </div>
      </div>

      <Tabs defaultValue="upload" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upload">Upload Data</TabsTrigger>
          <TabsTrigger value="jobs">Import Jobs</TabsTrigger>
          <TabsTrigger value="validation">Data Validation</TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-6">
          {/* Data Source Selection */}
          <Card className="p-6">
            <h2 className="mb-4">Select Data Source</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {(['CALPADS', 'CalSAWS', 'EDCS'] as const).map((source) => (
                <div
                  key={source}
                  className={`p-4 border-2 rounded-lg cursor-pointer transition-colors ${
                    selectedSource === source 
                      ? 'border-primary bg-accent' 
                      : 'border-border hover:bg-accent/50'
                  }`}
                  onClick={() => setSelectedSource(source)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium">{source}</h3>
                    <Database className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {source === 'CALPADS' && 'Student enrollment and meal program data'}
                    {source === 'CalSAWS' && 'Social services case management data'}
                    {source === 'EDCS' && 'Educational data and certification system'}
                  </p>
                  <div className="mt-2">
                    {getSourceBadge(source)}
                  </div>
                </div>
              ))}
            </div>
          </Card>

          {/* File Upload Area */}
          <Card className="p-6">
            <h2 className="mb-4">Upload {selectedSource} Data File</h2>
            
            <div
              className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                dragActive ? 'border-primary bg-accent/50' : 'border-muted-foreground/25'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
              <div className="space-y-2">
                <p className="text-lg font-medium">Drop {selectedSource} files here or click to browse</p>
                <p className="text-sm text-muted-foreground">
                  Supported formats: CSV, XML, Excel (Max 50MB per file)
                </p>
              </div>
              <input
                type="file"
                multiple
                accept=".csv,.xml,.xlsx,.xls"
                onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
                className="hidden"
                id="file-upload"
              />
              <label htmlFor="file-upload">
                <Button className="mt-4" asChild>
                  <span>Choose Files</span>
                </Button>
              </label>
            </div>

            {/* Import Configuration */}
            <div className="mt-6 space-y-4">
              <h3 className="font-medium">Import Configuration</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="flex items-center space-x-2">
                    <input type="checkbox" defaultChecked />
                    <span className="text-sm">Skip duplicate records</span>
                  </label>
                </div>
                <div>
                  <label className="flex items-center space-x-2">
                    <input type="checkbox" defaultChecked />
                    <span className="text-sm">Validate data format</span>
                  </label>
                </div>
                <div>
                  <label className="flex items-center space-x-2">
                    <input type="checkbox" />
                    <span className="text-sm">Auto-process after upload</span>
                  </label>
                </div>
                <div>
                  <label className="flex items-center space-x-2">
                    <input type="checkbox" defaultChecked />
                    <span className="text-sm">Send notification on completion</span>
                  </label>
                </div>
              </div>
            </div>
          </Card>

          {/* File Format Guidelines */}
          <Card className="p-6 bg-blue-50 border-blue-200">
            <h3 className="font-medium mb-3">File Format Requirements for {selectedSource}</h3>
            <div className="space-y-2 text-sm">
              {selectedSource === 'CALPADS' && (
                <>
                  <p>• Required columns: Student ID, Name, DOB, School, Grade, Free/Reduced Meal Status</p>
                  <p>• Date format: YYYY-MM-DD</p>
                  <p>• Encoding: UTF-8</p>
                  <p>• Maximum 100,000 records per file</p>
                </>
              )}
              {selectedSource === 'CalSAWS' && (
                <>
                  <p>• Required columns: Case ID, Household ID, Benefit Type, Status, Effective Date</p>
                  <p>• XML schema validation required</p>
                  <p>• Must include digital signature</p>
                  <p>• Maximum 50,000 records per file</p>
                </>
              )}
              {selectedSource === 'EDCS' && (
                <>
                  <p>• Required columns: Student ID, School Code, Meal Program, Certification Date</p>
                  <p>• Must match current school year format</p>
                  <p>• Include verification status</p>
                  <p>• Maximum 75,000 records per file</p>
                </>
              )}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="jobs" className="space-y-6">
          {/* Import Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Jobs</p>
                  <p className="text-2xl font-medium">12</p>
                </div>
                <FileText className="w-8 h-8 text-blue-600" />
              </div>
            </Card>
            
            <Card className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Processing</p>
                  <p className="text-2xl font-medium">1</p>
                </div>
                <RefreshCw className="w-8 h-8 text-orange-600" />
              </div>
            </Card>
            
            <Card className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-2xl font-medium">8</p>
                </div>
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
            </Card>
            
            <Card className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Failed</p>
                  <p className="text-2xl font-medium">3</p>
                </div>
                <FileX className="w-8 h-8 text-red-600" />
              </div>
            </Card>
          </div>

          {/* Import Jobs List */}
          <Card className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2>Import Jobs</h2>
              <Button variant="outline" size="sm">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
            
            <div className="space-y-3">
              {importJobs.map((job) => (
                <div
                  key={job.id}
                  className={`p-4 border border-border rounded-md cursor-pointer hover:bg-accent/50 transition-colors ${
                    selectedJob === job.id ? 'bg-accent border-primary' : ''
                  }`}
                  onClick={() => setSelectedJob(job.id)}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <h4 className="font-medium">{job.fileName}</h4>
                      {getSourceBadge(job.source)}
                      {getStatusBadge(job.status)}
                    </div>
                    <div className="flex gap-2">
                      {job.status === 'processing' && (
                        <Button size="sm" variant="outline">
                          <Pause className="w-4 h-4" />
                        </Button>
                      )}
                      {job.status === 'failed' && (
                        <Button size="sm" variant="outline">
                          <Play className="w-4 h-4" />
                        </Button>
                      )}
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  
                  {job.status === 'processing' && (
                    <div className="mb-3">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Progress</span>
                        <span>{job.progress}%</span>
                      </div>
                      <Progress value={job.progress} className="h-2" />
                    </div>
                  )}
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Total Records:</span> {job.totalRecords.toLocaleString()}
                    </div>
                    <div>
                      <span className="font-medium">Processed:</span> {job.processedRecords.toLocaleString()}
                    </div>
                    <div>
                      <span className="font-medium">Valid:</span> {job.validRecords.toLocaleString()}
                    </div>
                    <div>
                      <span className="font-medium">Errors:</span> {job.errorRecords.toLocaleString()}
                    </div>
                  </div>
                  
                  <div className="mt-2 text-sm text-muted-foreground">
                    Started: {job.startTime} • Size: {job.fileSize}
                    {job.endTime && ` • Completed: ${job.endTime}`}
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="validation" className="space-y-6">
          {/* Validation Rules */}
          <Card className="p-6">
            <h2 className="mb-4">Data Validation Rules</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-medium mb-3">CALPADS Validation</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span>Student ID format check</span>
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Date range validation</span>
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>School code verification</span>
                      <AlertCircle className="w-4 h-4 text-orange-600" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Duplicate detection</span>
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-3">CalSAWS Validation</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span>XML schema validation</span>
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Digital signature check</span>
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Case ID verification</span>
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Benefit status mapping</span>
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Validation Results */}
          <Card className="p-6">
            <h2 className="mb-4">Recent Validation Results</h2>
            <div className="space-y-3">
              <Alert>
                <AlertCircle className="w-4 h-4" />
                <div className="ml-2">
                  <h4 className="font-medium">CALPADS Import Warning</h4>
                  <p className="text-sm">125 records failed school code validation in recent import.</p>
                </div>
              </Alert>
              
              <Alert>
                <CheckCircle className="w-4 h-4" />
                <div className="ml-2">
                  <h4 className="font-medium">CalSAWS Import Success</h4>
                  <p className="text-sm">All records passed validation in latest CalSAWS import.</p>
                </div>
              </Alert>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}