import { Badge } from '../ui/badge';
import { STATUS_VARIANTS } from './constants';

export const getStatusBadge = (status: string) => {
  const variant = STATUS_VARIANTS[status as keyof typeof STATUS_VARIANTS] || 'outline';
  return (
    <Badge variant={variant}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </Badge>
  );
};