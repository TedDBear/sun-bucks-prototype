import React from 'react';
import { Card } from '../ui/card';
import { Input } from '../ui/input';
import { Button } from '../ui/button';
import { Search, Filter, Download } from 'lucide-react';

export function SearchAndFilters() {
  return (
    <Card className="p-4">
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
          <Input className="pl-10" placeholder="Search by case ID, name, or household ID..." />
        </div>
        <div className="flex gap-2">
          <select className="px-3 py-2 border border-border rounded-md bg-background">
            <option>All Status</option>
            <option>Approved</option>
            <option>Pending</option>
            <option>Under Review</option>
            <option>Rejected</option>
          </select>
          <select className="px-3 py-2 border border-border rounded-md bg-background">
            <option>All Eligibility</option>
            <option>Direct Certification</option>
            <option>Manual Review</option>
            <option>Income Verified</option>
          </select>
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            More Filters
          </Button>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>
    </Card>
  );
}