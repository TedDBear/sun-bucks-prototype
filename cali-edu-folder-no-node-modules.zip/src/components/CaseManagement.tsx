import React, { useState } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { CASE_DATA } from './case-management/constants';
import { CaseListItem } from './case-management/CaseListItem';
import { CaseDetailsPanel } from './case-management/CaseDetailsPanel';
import { SearchAndFilters } from './case-management/SearchAndFilters';

interface CaseManagementProps {
  onCaseSelect?: (caseId: string) => void;
}

export function CaseManagement({ onCaseSelect }: CaseManagementProps) {
  const [selectedCase, setSelectedCase] = useState<string | null>(null);
  const [caseNotes, setCaseNotes] = useState('');

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1>Case Management</h1>
          <p className="text-muted-foreground">Search, filter and manage SUN Bucks cases</p>
        </div>
        <Button>New Case</Button>
      </div>

      <SearchAndFilters />

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Cases List */}
        <div className="xl:col-span-2">
          <Card className="p-6">
            <div className="space-y-4">
              {CASE_DATA.map((case_item) => (
                <CaseListItem
                  key={case_item.id}
                  case_item={case_item}
                  isSelected={selectedCase === case_item.id}
                  onSelect={setSelectedCase}
                  onCaseSelect={onCaseSelect}
                />
              ))}
            </div>
          </Card>
        </div>

        {/* Case Details Panel */}
        <div className="xl:col-span-1">
          <CaseDetailsPanel
            selectedCase={selectedCase}
            caseNotes={caseNotes}
            setCaseNotes={setCaseNotes}
          />
        </div>
      </div>
    </div>
  );
}